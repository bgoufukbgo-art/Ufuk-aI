plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.ufukai.app"; compileSdk=36; defaultConfig { applicationId="com.ufukai.app"; minSdk=26; targetSdk=36; versionCode=2; versionName="0.2" } }
dependencies { implementation("androidx.core:core-ktx:1.17.0"); implementation("androidx.activity:activity-ktx:1.10.1"); implementation("androidx.appcompat:appcompat:1.7.1"); implementation("com.google.android.material:material:1.13.0") }
