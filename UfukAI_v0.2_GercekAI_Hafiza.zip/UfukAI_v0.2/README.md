# UFUK AI v0.2
Android istemcisi + güvenli backend. API anahtarı APK'ya konmaz.
Backend: cd backend && npm install && cp .env.example .env && npm start
Android emülatöründe backend adresi: http://10.0.2.2:8080
Gerçek telefonda HTTPS backend adresini MainActivity.kt içindeki baseUrl ile değiştir.
